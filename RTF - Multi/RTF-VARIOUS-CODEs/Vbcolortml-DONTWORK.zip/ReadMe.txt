       HTML Syntax Highlighting

E-Mail: vhtml@hotmail.com

Author:  David Hoyt

Website: http://vhtml.hypermart.net/

General Info.
     HTML syntax highlighting can be done easier than other languages b/c it follows a set pattern.  You have tags, attributes, comments, and text.  That's about it...So to make highlighting faster, I created a routine that works just for HTML.  It's faster b/c it follows the set pattern for HTML instead of just finding keywords and highlighting those.
     It works by first going and putting in the correct RTF color table switches and then storing all text up to an HTML tag (thus making it faster if you have more text b/c it skips everything in between).  Then it highlights an individual tag at a time.  It goes through and evaluates each tag and its constituients.  It's pretty basic...anything to the left of an equal sign in the tag is going to be an attribute name (this color is the same as the tag color...I'll work on creating separate colors for this), and anything to the right will be the attribute value (colored in blue in the example).  It will color values even if they're not enclosed in quotes.  When you go to the next space, then we know we're at another attribute name EXCEPT in cases when we're in a quote.  I had to add some code to make sure it didn't evaluate the next word after a space as an attribute name instead of as part of the quote.  But that's all taken care of, so don't fret!  (c:  It will color comments as well.

Problems
     Don't try using TagBold, TagItalics, etc. b/c in some configurations it will cause it to freeze and I don't know why yet.  I will work on that.  But it does work fine w/ any color configuration.  You can use common dialogs to allow the user to select a color and it will work fine w/ those.  It automattically interprets the colors and applies them to the RTF.

Requirements
     It requires the SSubtmr.dll available from vbAccelerator.
Implementation
     It's rather simple, actually...I have it set up w/ an RTB made through code, but you can easily switch it to a normal RTB by changing the "Public RichTxtBox As HSRichEdit" to "Public RichTxtBox As RichTextBox".  After that, to highlight, just use two lines of code:

  Set syntaxHighlight1.RichTxtBox =  RichTextBox1
  syntaxHighlight1.Highlight

     To get it to color properly while typing, use the following code:

  Private Sub RichTextBox1_KeyPress(KeyAscii As Integer)
    KeyAscii = syntaxHighlight1.KeyPressEvent(KeyAscii)
  End Sub

     That's all it takes to set it up!  Good luck!  (c;

-David Hoyt