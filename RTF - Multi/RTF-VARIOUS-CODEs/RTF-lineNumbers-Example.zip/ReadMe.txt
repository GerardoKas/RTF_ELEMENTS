Welcome to the Gutter Demonstration.
------------------------------------------------------------------------------------------

Last Updated: 3-30-00 Version 3

Latest Updates:
	as of 4-18-00
	1. Added a gutter with line numbering using the api and subclassing

Known Issues:
	1. The line numbers in the gutter get off on Windows 2000 machines. I can not figure
		it out. If anyone can please let me know. Otherwise the gutter numbers work
		as they are supposed to under Windows 98/95/NT. Sometimes you have to hate 
		Microsoft

##########################################################################################

Below you will find the information you need to run this application.

System Requirements to run and compile the control:

Pentium w/ 16 meg of ram (estimate)
Windows 95/98/NT

at least Visual Basic 5.0 (included in Visual Studio 97) to open and compile the project

##########################################################################################

About the Program

This was written To show people how to do line numbers in the gutter and also how to 
scroll the gutter with the RTB using the API

-----------------------------------------------------------------------------------------

This code is GPL'd so please read the documentation file that comes with this control and app.

That's about it. Any questions or comments please contact me, Eric Banker, at:
ebanker@gmu.edu

Flames will be ignored :)
enjoy

This code is copyright me Eric Banker in the year 2000
Eric Banker

I would like to say thanks to a few people for helping out with this program. 

All of the guys at VBAcclerator for the work they have done. Thanks for the use of the Drawlines function!

Thanks to all of you. 