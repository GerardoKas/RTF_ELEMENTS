Title: Power Notepad
Description: This is a very powerful notepad example. It is probably one of the best notepad examples on plantet-source-code. It also has a built in HTML editor, allows you to add images and pictures, spell check, and dozens of more options.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=12107&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
