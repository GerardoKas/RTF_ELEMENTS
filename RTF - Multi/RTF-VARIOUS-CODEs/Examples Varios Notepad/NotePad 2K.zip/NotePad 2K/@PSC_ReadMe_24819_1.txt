Title: NotePad 2K
Description: Looking for a word processing application to find out how things work or 
just need one to work for you...<br>
well this program uses a rtf text box....<br>
It has an awesome list of features, take a look and download....<br>
Worth a Look....<br><br>
Vote if you Like...<br><br>
~Progress bar for loading files<br>
~Insert Picture or Objects<br>
~Has Multi Encryption Support<br>
~Also Has Recent Docs in File Menu<br>
~Preview Font(This is cool)<br>
~Find and Replace is Finally Fixed(I think)<br>
~Now adds All Documents loaded to Documents Folder<br>
~Updated, shouldn't have any errors...<br>
Thanks<br>
I don't Think you'll regret this download
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=24819&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
